﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Calcuator
{
    class Program
    {
        static void Main(string[] args)
        {
            var zoneDetailsPath = ConfigurationManager.AppSettings["ZoneDetailsPath"];
            try
            {
                if (String.IsNullOrEmpty(zoneDetailsPath) || !File.Exists(zoneDetailsPath))
                    throw new Exception("No valid zone details file path in app.config");

                ZoneDetails zoneDetails;
                using (var fs = new FileStream(zoneDetailsPath, FileMode.Open))
                {
                    var serializer = new XmlSerializer(typeof(ZoneDetails));
                    zoneDetails = serializer.Deserialize(fs) as ZoneDetails;
                }

                Console.Write("Fare Type (Enter “1” for Full Fare and “2” for Concession): ");
                var val = Console.ReadLine();
                var fareTypeCode = Convert.ToInt32(val);

                Console.Write("Number of days to travel on weekdays: ");
                val = Console.ReadLine();
                var weekDays = Convert.ToInt32(val);
                if ((weekDays < 0) || (weekDays > 5))
                    throw new Exception("Weekdays should be between 0 and 5");

                Console.Write("Number of days to travel on weekends: ");
                val = Console.ReadLine();
                var weekendDays = Convert.ToInt32(val);
                if ((weekendDays < 0) || (weekendDays > 2))
                    throw new Exception("Weekend days should be between 0 and 2");

                Console.Write("Number of weeks you are planning to travel: ");
                val = Console.ReadLine();
                var numberOfWeeks = Convert.ToInt32(val);
                if ((numberOfWeeks < 1) || (numberOfWeeks > 52))
                    throw new Exception("Number of weeks should be between 1 and 52");


                var calculatorFactory = new CalculatorFactory(zoneDetails);
                var calc = calculatorFactory.CalculatorForZone();

                decimal movePass, moveMoney;
                calc.Calculate(fareTypeCode, weekDays, weekendDays, numberOfWeeks, out moveMoney, out movePass);
                Console.WriteLine("The amount in “Move Money”: " + moveMoney.ToString("C2"));
                Console.WriteLine("The amount in “Move Pass”: " + movePass.ToString("C2"));
                Console.WriteLine("Recommendation: " + ((moveMoney > movePass) ? "“Move Pass”" : "“Move Money”"));
            }
            catch (Exception ex)
            {
                Console.BackgroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Error: " + ex.Message);
            }

            Console.ReadLine();
        }
    }
}
