﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calcuator
{

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public partial class ZoneDetails
    {

        private Zone[] zoneField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Zone")]
        public Zone[] Zone
        {
            get
            {
                return this.zoneField;
            }
            set
            {
                this.zoneField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class Zone
    {

        private MoveMoney moveMoneyField;

        private MovePass movePassField;

        private string nameField;

        /// <remarks/>
        public MoveMoney MoveMoney
        {
            get
            {
                return this.moveMoneyField;
            }
            set
            {
                this.moveMoneyField = value;
            }
        }

        /// <remarks/>
        public MovePass MovePass
        {
            get
            {
                return this.movePassField;
            }
            set
            {
                this.movePassField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class MoveMoney
    {

        private MoveMoneyFareType[] fareTypesField;

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("FareType", IsNullable = false)]
        public MoveMoneyFareType[] FareTypes
        {
            get
            {
                return this.fareTypesField;
            }
            set
            {
                this.fareTypesField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class MoveMoneyFareType
    {

        private WeekdayRate weekdayRateField;

        private WeekendRate weekendRateField;

        private string nameField;

        private byte codeField;

        private string nameField1;

        /// <remarks/>
        public WeekdayRate WeekdayRate
        {
            get
            {
                return this.weekdayRateField;
            }
            set
            {
                this.weekdayRateField = value;
            }
        }

        /// <remarks/>
        public WeekendRate WeekendRate
        {
            get
            {
                return this.weekendRateField;
            }
            set
            {
                this.weekendRateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte Code
        {
            get
            {
                return this.codeField;
            }
            set
            {
                this.codeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string name
        {
            get
            {
                return this.nameField1;
            }
            set
            {
                this.nameField1 = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class WeekdayRate
    {

        private decimal rateField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public decimal Rate
        {
            get
            {
                return this.rateField;
            }
            set
            {
                this.rateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class WeekendRate
    {

        private decimal rateField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public decimal Rate
        {
            get
            {
                return this.rateField;
            }
            set
            {
                this.rateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class MovePass
    {

        private MovePassFareType[] fareTypesField;

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("FareType", IsNullable = false)]
        public MovePassFareType[] FareTypes
        {
            get
            {
                return this.fareTypesField;
            }
            set
            {
                this.fareTypesField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class MovePassFareType
    {

        private WeeklyRate weeklyRateField;

        private DailyRate dailyRateField;

        private string nameField;

        private byte codeField;

        /// <remarks/>
        public WeeklyRate WeeklyRate
        {
            get
            {
                return this.weeklyRateField;
            }
            set
            {
                this.weeklyRateField = value;
            }
        }

        /// <remarks/>
        public DailyRate DailyRate
        {
            get
            {
                return this.dailyRateField;
            }
            set
            {
                this.dailyRateField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public byte Code
        {
            get
            {
                return this.codeField;
            }
            set
            {
                this.codeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class WeeklyRate
    {

        private decimal rateField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public decimal Rate
        {
            get
            {
                return this.rateField;
            }
            set
            {
                this.rateField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class DailyRate
    {

        private decimal rateField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public decimal Rate
        {
            get
            {
                return this.rateField;
            }
            set
            {
                this.rateField = value;
            }
        }
    }


}
