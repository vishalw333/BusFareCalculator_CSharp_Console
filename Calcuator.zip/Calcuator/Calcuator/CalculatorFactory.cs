﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calcuator
{
    public class CalculatorFactory
    {
        private readonly ZoneDetails _zoneDetails;

        public CalculatorFactory(ZoneDetails zoneDetails)
        {
            _zoneDetails = zoneDetails;
        }

        public ICalculator CalculatorForZone(string zoneName = "")
        {
            var zone = String.IsNullOrEmpty(zoneName) ? _zoneDetails.Zone.First() : 
                _zoneDetails.Zone.FirstOrDefault(x => x.Name == zoneName);
            return new ZoneCalculator(zone);
        }
    }
}
