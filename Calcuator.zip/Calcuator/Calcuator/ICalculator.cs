﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calcuator
{
    public interface ICalculator
    {
        void Calculate(int fareTypeCode, int weekdays, int weekendDays, int weeks,
            out decimal moveMoney, out decimal movePass);
        
    }
}
